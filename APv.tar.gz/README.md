# Automata-de-Pila

- Implementacion de un automata de pila por vaciado de pila en lenguaje C++.

   *Imar Abreu Diaz*